# 荀子：学术解释与现代边界
调研：2026-10-02。

[Stanford Encyclopedia of Philosophy，Xunzi](https://plato.stanford.edu/entries/xunzi/)实际读生平、性伪、礼乐、天及道的争议、名实相关选段。重点方法提醒：性与孟子所说的性不能先当同义；“伪”指人为习得；文本及生平有不确定性。未通读其引列研究。

## 原典与现代批判
[礼论](https://zh.wikisource.org/wiki/荀子/禮論篇)承认欲求需要养护，不能把荀子只归为压制欲望。
[解蔽](https://zh.wikisource.org/wiki/荀子/解蔽篇)反对各家一隅，但又认定统一的道；不包装成现代价值相对主义。
[正名](https://zh.wikisource.org/wiki/荀子/正名篇)既分析语言沟通，也包含对异说与等级的控制；标准化有价值，不能直接授权打压不同意见。
[天论](https://zh.wikisource.org/wiki/荀子/天論篇)重人事不等于现代科学完整方法，灾难损失也不都由失治造成。
后天塑造模型必须保留人的权利、意愿与能力差异。现代自主、申诉、公平校正是本次迁移判断，不伪称古人原有观念。
